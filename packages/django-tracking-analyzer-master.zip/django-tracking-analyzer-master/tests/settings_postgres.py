from .settings import *


DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': '',
        'USERNAME': 'postgres',
        'PASSWORD': '',
    }
}
