
from django.core.exceptions import ValidationError


class LiqPayValidationError(ValidationError):
    pass
