VERSION = (0, 5, 3,)
__version__ = '.'.join(map(str, VERSION))
default_app_config = 'django_messages.apps.DjangoMessagesConfig'
